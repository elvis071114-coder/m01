#!/bin/bash
# M-01 Companion 安裝程式
SRC="$(cd "$(dirname "$0")"; pwd)"
# builds the native app window ($1 = app path, $2 = port, $3 = bundle id suffix)
build_app(){
  local APP="$1" PORT="$2" SUF="$3" TMPJS
  TMPJS="$(mktemp -t m01shell).js"
  sed -e "s|__PORT__|$PORT|" -e "s|__DATA__|~/Documents/Companion|" "$SRC/shell.js" > "$TMPJS"
  rm -rf "$APP"
  /usr/bin/osacompile -l JavaScript -s -o "$APP" "$TMPJS" || { echo "建立 App 失敗"; exit 1; }
  rm -f "$TMPJS"
  mkdir -p "$APP/Contents/Resources/web"
  cp "$SRC/index.html" "$APP/Contents/Resources/web/index.html"
  cp "$SRC/server.pl" "$APP/Contents/Resources/server.pl"
  cp "$SRC/AppIcon.icns" "$APP/Contents/Resources/applet.icns"
  # newer macOS applets take their icon from Assets.car; drop it so our icon is used
  rm -f "$APP/Contents/Resources/Assets.car"
  local PL="$APP/Contents/Info.plist"
  /usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier local.m01.companion$SUF" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string local.m01.companion$SUF" "$PL"
  /usr/libexec/PlistBuddy -c "Set :CFBundleName M-01 Companion" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Delete :CFBundleIconName" "$PL" 2>/dev/null || true
  # allow the microphone and speech recognition inside the app window
  /usr/libexec/PlistBuddy -c "Delete :NSMicrophoneUsageDescription" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :NSMicrophoneUsageDescription string 用麥克風讓你直接用說的跟她聊天" "$PL"
  /usr/libexec/PlistBuddy -c "Delete :NSSpeechRecognitionUsageDescription" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :NSSpeechRecognitionUsageDescription string 把你說的話轉成文字" "$PL"
  /usr/libexec/PlistBuddy -c "Set :CFBundleIconFile applet" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :CFBundleIconFile string applet" "$PL"
  /usr/bin/codesign --force --deep -s - "$APP" >/dev/null 2>&1 || true
  touch "$APP"
  # refresh the Finder / Dock icon cache for this app
  /System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP" >/dev/null 2>&1 || true
  # restart the helper so it serves the files of this build
  pkill -f "server.pl.* $PORT\$" >/dev/null 2>&1 || true
}
echo "== 安裝 M-01 Companion =="
if [ ! -d "/Applications/Ollama.app" ] && ! command -v ollama >/dev/null 2>&1; then echo "請先安裝 Ollama。"; open "https://ollama.com/download"; exit 0; fi
DEST="/Applications"; [ -w "$DEST" ] || { DEST="$HOME/Applications"; mkdir -p "$DEST"; }
mkdir -p "$HOME/Documents/Companion"
# make sure Ollama is running, then download a chat model (you choose the size)
OLL="$(command -v ollama || echo /Applications/Ollama.app/Contents/Resources/ollama)"
if ! curl -s -m 2 http://localhost:11434/api/tags >/dev/null 2>&1; then
  open -a Ollama >/dev/null 2>&1
  for i in $(seq 1 40); do curl -s -m 2 http://localhost:11434/api/tags >/dev/null 2>&1 && break; sleep 1; done
fi
if curl -s -m 5 http://localhost:11434/api/tags | grep -qE '"qwen2\.5:(7b|3b)"'; then
  echo "已經有聊天模型，跳過下載。"
else
  echo ""
  echo "要下載哪一個聊天模型？"
  echo "  1) 標準版 qwen2.5:7b — 約 4.7GB，比較聰明、比較會照個性說話（建議）"
  echo "  2) 輕量版 qwen2.5:3b — 約 1.9GB，下載快、比較省空間，但比較容易答錯"
  CH=""; read -r -p "輸入 1 或 2 再按 Enter（直接按 Enter 就是 1）： " CH </dev/tty || true
  MODEL="qwen2.5:7b"; [ "$CH" = "2" ] && MODEL="qwen2.5:3b"
  echo "正在下載 $MODEL（第一次需要幾分鐘）..."
  "$OLL" pull "$MODEL" || echo "⚠️ 模型下載沒有完成。之後可以在終端機執行：ollama pull $MODEL"
fi
build_app "$DEST/M-01 Companion.app" 47811 ""
# keep Ollama accepting this app after every restart
AGENT="$HOME/Library/LaunchAgents/local.m01.ollama-origins.plist"; mkdir -p "$HOME/Library/LaunchAgents"
cat > "$AGENT" <<'AG'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>Label</key><string>local.m01.ollama-origins</string>
<key>ProgramArguments</key><array><string>/bin/launchctl</string><string>setenv</string><string>OLLAMA_ORIGINS</string><string>*</string></array>
<key>RunAtLoad</key><true/></dict></plist>
AG
launchctl unload "$AGENT" >/dev/null 2>&1; launchctl load "$AGENT" >/dev/null 2>&1
rm -rf "$HOME/Library/Application Support/M-01 Companion/browser"
echo "已安裝版本：$(grep -o 'APP_VER="[0-9.]*"' "$SRC/index.html" | head -1 | cut -d\" -f2)（打開 App 後點右上角 ⓘ 應該也是這個版本）"
echo "✅ 安裝完成：$DEST/M-01 Companion.app"
open "$DEST/M-01 Companion.app"
