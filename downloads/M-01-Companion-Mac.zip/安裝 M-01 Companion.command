#!/bin/bash
# M-01 Companion 安裝程式
SRC="$(cd "$(dirname "$0")"; pwd)"
# builds the native app window ($1 = app path, $2 = port, $3 = bundle id suffix)
build_app(){
  local APP="$1" PORT="$2" SUF="$3" TMPJS
  TMPJS="$(mktemp -t m01shell).js"
  sed -e "s|__PORT__|$PORT|" -e "s|__DATA__|~/Library/Application Support/M-01 Companion/Data|" "$SRC/shell.js" > "$TMPJS"
  rm -rf "$APP"
  /usr/bin/osacompile -l JavaScript -s -o "$APP" "$TMPJS" || { echo "建立 App 失敗 / Couldn't build the app"; exit 1; }
  rm -f "$TMPJS"
  mkdir -p "$APP/Contents/Resources/web"
  cp "$SRC/index.html" "$APP/Contents/Resources/web/index.html"
  cp "$SRC/server.pl" "$APP/Contents/Resources/server.pl"
  cp "$SRC/gclient.txt" "$APP/Contents/Resources/gclient.txt" 2>/dev/null || true
  cp "$SRC/pkgver.txt" "$APP/Contents/Resources/pkgver.txt" 2>/dev/null || true
  cp "$SRC/AppIcon.icns" "$APP/Contents/Resources/applet.icns"
  # newer macOS applets take their icon from Assets.car; drop it so our icon is used
  rm -f "$APP/Contents/Resources/Assets.car"
  local PL="$APP/Contents/Info.plist"
  /usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier local.m01.companion$SUF" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :CFBundleIdentifier string local.m01.companion$SUF" "$PL"
  /usr/libexec/PlistBuddy -c "Set :CFBundleName M-01 Companion" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Delete :CFBundleIconName" "$PL" 2>/dev/null || true
  # allow the microphone and speech recognition inside the app window
  /usr/libexec/PlistBuddy -c "Delete :NSMicrophoneUsageDescription" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :NSMicrophoneUsageDescription string 用麥克風讓你直接用說的跟她聊天" "$PL"
  /usr/libexec/PlistBuddy -c "Delete :NSSpeechRecognitionUsageDescription" "$PL" 2>/dev/null || true
  /usr/libexec/PlistBuddy -c "Add :NSSpeechRecognitionUsageDescription string 把你說的話轉成文字" "$PL"
  /usr/libexec/PlistBuddy -c "Set :CFBundleIconFile applet" "$PL" 2>/dev/null || /usr/libexec/PlistBuddy -c "Add :CFBundleIconFile string applet" "$PL"
  /usr/bin/codesign --force --deep -s - "$APP" >/dev/null 2>&1 || true
  touch "$APP"
  # refresh the Finder / Dock icon cache for this app
  /System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP" >/dev/null 2>&1 || true
  # restart the helper so it serves the files of this build
  pkill -f "server\.pl.* $PORT( |\$)" >/dev/null 2>&1 || true   # the helper is started as: perl server.pl WEB DATA PORT BUNDLE
}
echo "== 安裝 M-01 Companion / Installing M-01 Companion =="
# only the app is installed here; the AI (Gemini, local AI via Ollama, or Claude) is set up inside the app after signing in
DEST="/Applications"; [ -w "$DEST" ] || { DEST="$HOME/Applications"; mkdir -p "$DEST"; }
build_app "$DEST/M-01 Companion.app" 47811 ""
# keep Ollama accepting this app after every restart
AGENT="$HOME/Library/LaunchAgents/local.m01.ollama-origins.plist"; mkdir -p "$HOME/Library/LaunchAgents"
cat > "$AGENT" <<'AG'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>Label</key><string>local.m01.ollama-origins</string>
<key>ProgramArguments</key><array><string>/bin/launchctl</string><string>setenv</string><string>OLLAMA_ORIGINS</string><string>*</string></array>
<key>RunAtLoad</key><true/></dict></plist>
AG
launchctl unload "$AGENT" >/dev/null 2>&1; launchctl load "$AGENT" >/dev/null 2>&1
rm -rf "$HOME/Library/Application Support/M-01 Companion/browser"
VER="$(grep -o 'APP_VER="[0-9.]*"' "$SRC/index.html" | head -1 | cut -d\" -f2)"
echo "已安裝版本 / Installed version: $VER（打開 App 後點右上角 ⓘ 應該也是這個版本 / the ⓘ button in the app should show the same）"
echo "✅ 安裝完成 / Done: $DEST/M-01 Companion.app"
echo "打開 App 後：先用 Google 登入，再選要用哪個 AI（Gemini、本地 AI 或 Claude），照畫面做就好。"
echo "In the app: sign in with Google, then choose an AI (Gemini, local AI or Claude) and follow the steps on screen."
open "$DEST/M-01 Companion.app"
