// M-01 Companion native window (JavaScript for Automation, compiled into a stay-open applet).
// Shows the app in its own window with its own Dock icon; no Chrome needed.
ObjC.import('Cocoa');
ObjC.import('WebKit');

var PORT = __PORT__;
var DATA_DIR = '__DATA__';
var sys = Application.currentApplication();
sys.includeStandardAdditions = true;
var win = null, web = null;

function sh(cmd) { try { return sys.doShellScript(cmd); } catch (e) { return ''; } }
function q(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'"; }

function startServices() {
  var res = $.NSBundle.mainBundle.resourcePath.js;
  var home = sh('echo $HOME');
  var data = DATA_DIR.replace(/^~/, home);
  // older versions kept the memory folder in Documents/Companion; move it to the app's own folder once (unless the user picked a place themselves)
  var support = home + '/Library/Application Support/M-01 Companion';
  var oldData = home + '/Documents/Companion';
  if (data !== oldData && sh('[ -d ' + q(oldData) + ' ] && [ ! -e ' + q(data) + ' ] && [ ! -s ' + q(support + '/datadir.txt') + ' ] && echo y') === 'y') {
    sh('mkdir -p ' + q(support) + ' && mv ' + q(oldData) + ' ' + q(data));
  }
  sh('mkdir -p ' + q(data));
  // local helper that serves the app and reads/writes the memory folder
  // a helper left running from an older install is replaced, so new features (like music) work right away
  var ping = sh('curl -s -m 1 -H "X-M01: 1" http://127.0.0.1:' + PORT + '/ping');
  // the helper can update itself: a newer copy saved in the app's folder wins over the one inside the app
  var hvOf = function (p) { return parseInt(sh("grep -o 'my \\$HV = [0-9]*' " + q(p) + " 2>/dev/null | grep -o '[0-9]*$'"), 10) || 0; };
  var script = res + '/server.pl', want = hvOf(script), ovr = support + '/helper/server.pl', ovrHv = hvOf(ovr);
  if (ovrHv > want) { script = ovr; want = ovrHv; }
  var have = 0; try { have = JSON.parse(ping).hv || 1; } catch (e) { have = ping ? 1 : 0; }
  if (ping !== '' && want && have < want) {
    sh('pkill -f ' + q('server\\.pl.* ' + PORT + '( |$)') + ' >/dev/null 2>&1 || true'); delay(0.6); ping = '';
  }
  if (ping === '') {
    sh('nohup /usr/bin/perl ' + q(script) + ' ' + q(res + '/web') + ' ' + q(data) + ' ' + PORT + ' ' + q(String($.NSBundle.mainBundle.bundleIdentifier.js || '')) + ' >/dev/null 2>&1 &');
    for (var i = 0; i < 100; i++) { if (sh('curl -s -m 1 -H "X-M01: 1" http://127.0.0.1:' + PORT + '/ping') !== '') break; delay(0.1); }
  }
  // Ollama: start it and make sure it accepts requests from this window.
  // This runs in the background, so the window opens right away (the app waits for Ollama by itself).
  sh('launchctl setenv OLLAMA_ORIGINS "*"');
  var hasOllama = sh('{ [ -d /Applications/Ollama.app ] || [ -d "$HOME/Applications/Ollama.app" ] || command -v ollama >/dev/null 2>&1; } && echo y') === 'y';
  if (!hasOllama) return;
  var chk = 'curl -s -m 2 -o /dev/null -w "%{http_code}" -H "Origin: http://127.0.0.1:' + PORT + '" http://localhost:11434/api/tags';
  var bg = 'c=$(' + chk + '); [ "$c" = 000 ] && open -g -a Ollama; ' +
    'for i in $(seq 1 30); do c=$(' + chk + '); ' +
    'if [ "$c" = 403 ]; then osascript -e \'quit app "Ollama"\'; sleep 2; open -g -a Ollama; exit 0; fi; ' +
    '[ "$c" = 000 ] || exit 0; sleep 1; done';
  sh('nohup /bin/bash -c ' + q(bg) + ' >/dev/null 2>&1 &');
}

function openWindow() {
  if (win) { win.makeKeyAndOrderFront(null); $.NSApp.activateIgnoringOtherApps(true); return; }
  var rect = $.NSMakeRect(0, 0, 1440, 900);
  // titled | closable | miniaturizable | resizable
  win = $.NSWindow.alloc.initWithContentRectStyleMaskBackingDefer(rect, 15, 2, false);
  win.releasedWhenClosed = false;
  win.title = 'M-01 Companion';
  win.minSize = $.NSMakeSize(900, 600);
  win.backgroundColor = $.NSColor.colorWithSRGBRedGreenBlueAlpha(0.035, 0.035, 0.043, 1);
  var conf = $.WKWebViewConfiguration.alloc.init;
  conf.mediaTypesRequiringUserActionForPlayback = 0;   // allow boot / button sounds
  web = $.WKWebView.alloc.initWithFrameConfiguration(rect, conf);
  web.autoresizingMask = 18;                            // width + height sizable
  win.contentView = web;
  win.center;
  win.makeKeyAndOrderFront(null);
  $.NSApp.activateIgnoringOtherApps(true);
  web.loadRequest($.NSURLRequest.requestWithURL($.NSURL.URLWithString('http://127.0.0.1:' + PORT + '/?app=1')));
}

// called by the helper (/dictate): opens macOS dictation for the focused text box
function dictate() {
  if (win) { win.makeKeyAndOrderFront(null); $.NSApp.activateIgnoringOtherApps(true); }
  $.NSApp.sendActionToFrom('startDictation:', $(), $());
  return 'ok';
}

function run() { startServices(); openWindow(); }
function reopen() { openWindow(); }
