# M-01 Companion launcher (Windows)
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 47811
$data = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Companion'
$prof = Join-Path $env:LOCALAPPDATA 'M-01 Companion\browser'
New-Item -ItemType Directory -Path $data, $prof -Force | Out-Null

# already open? bring it to the front instead of opening another window
$open = Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*$prof*" }
if ($open) { $wsh = New-Object -ComObject WScript.Shell; $null = $wsh.AppActivate('M-01 Companion'); exit }

function Test-Helper { try { (Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$port/ping" -Headers @{ 'X-M01' = '1' } -TimeoutSec 1).StatusCode -eq 200 } catch { $false } }
if (-not (Test-Helper)) {
  Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$base\server.ps1`"",'-WebRoot',"`"$base\web`"",'-DataDir',"`"$data`"",'-Port',"$port")
  for ($i = 0; $i -lt 40 -and -not (Test-Helper); $i++) { Start-Sleep -Milliseconds 300 }
}

function Test-Ollama { try { Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 | Out-Null; $true } catch { $false } }
if (-not (Test-Ollama)) {
  $exe = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama app.exe'
  if (Test-Path $exe) { Start-Process $exe }
  for ($i = 0; $i -lt 30 -and -not (Test-Ollama); $i++) { Start-Sleep -Seconds 1 }
}

$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $edge) { Start-Process "http://127.0.0.1:$port/"; exit }
Start-Process $edge -ArgumentList @("--app=http://127.0.0.1:$port/", "--user-data-dir=`"$prof`"", '--window-size=1440,900', '--no-first-run', '--autoplay-policy=no-user-gesture-required')
