# M-01 Companion launcher (Windows): gets the window on screen as fast as possible.
$ProgressPreference = 'SilentlyContinue'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 47811
$appRoot = Join-Path $env:LOCALAPPDATA 'M-01 Companion'
$data = Join-Path $appRoot 'Data'
$prof = Join-Path $appRoot 'browser'

# already open? bring it to the front instead of opening another window.
# Edge keeps a 'lockfile' open in its profile folder while it runs, so this check is instant.
function Test-WindowOpen {
  $lf = Join-Path $prof 'lockfile'
  if (-not [IO.File]::Exists($lf)) { return $false }
  try { $fs = [IO.File]::Open($lf, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None); $fs.Close(); return $false } catch { return $true }
}
if (Test-WindowOpen) {
  try { $wsh = New-Object -ComObject WScript.Shell; $null = $wsh.AppActivate('M-01 Companion') } catch { }
  exit
}

# older versions kept the memory folder in Documents\Companion; move it here once (unless the user picked a place themselves)
$oldData = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Companion'
$cfgFile = Join-Path $appRoot 'datadir.txt'
if (-not (Test-Path -LiteralPath $data) -and (Test-Path -LiteralPath $oldData) -and -not ((Test-Path -LiteralPath $cfgFile) -and ((Get-Item -LiteralPath $cfgFile).Length -gt 0))) {
  try { Move-Item -LiteralPath $oldData -Destination $data -ErrorAction Stop } catch { $data = $oldData }
}
if (-not (Test-Path -LiteralPath $data)) { New-Item -ItemType Directory -Path $data -Force | Out-Null }
if (-not (Test-Path -LiteralPath $prof)) { New-Item -ItemType Directory -Path $prof -Force | Out-Null }

# quick local checks (no proxy lookup, short timeouts)
function Test-Port([int]$p, [int]$ms) {
  $c = New-Object Net.Sockets.TcpClient
  try { $ar = $c.BeginConnect('127.0.0.1', $p, $null, $null); if ($ar.AsyncWaitHandle.WaitOne($ms) -and $c.Connected) { return $true }; return $false } catch { return $false } finally { $c.Close() }
}
function Get-Ping {
  try {
    $rq = [Net.HttpWebRequest]::Create("http://127.0.0.1:$port/ping")
    $rq.Proxy = $null; $rq.Timeout = 1500; $rq.Headers['X-M01'] = '1'
    $rs = $rq.GetResponse(); $sr = New-Object IO.StreamReader($rs.GetResponseStream()); $t = $sr.ReadToEnd(); $rs.Close(); return $t
  } catch { return $null }
}

# local AI is optional: if Ollama is installed, start it now but don't wait for it (the app waits for it by itself)
$oll = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama app.exe'
if ((Test-Path -LiteralPath $oll) -and -not (Test-Port 11434 150)) { try { Start-Process -FilePath $oll -WindowStyle Hidden } catch { } }

# the background helper: start it if it isn't running; replace it when this install (or a self-update) has a newer one
function Get-Hv([string]$f) { try { $m = [regex]::Match([IO.File]::ReadAllText($f), '\$HV = (\d+)'); if ($m.Success) { return [int]$m.Groups[1].Value } } catch { }; return 0 }
$script = Join-Path $base 'server.ps1'; $wantHv = Get-Hv $script
$ovr = Join-Path $appRoot 'helper\server.ps1'; $ovrHv = Get-Hv $ovr
if ($ovrHv -gt $wantHv) { $script = $ovr; $wantHv = $ovrHv }
$running = Test-Port $port 300
if ($running) {
  $haveHv = 0; $pt = Get-Ping
  if ($pt) { $m = [regex]::Match($pt, '"hv"\s*:\s*(\d+)'); if ($m.Success) { $haveHv = [int]$m.Groups[1].Value } }
  if ($wantHv -gt 0 -and $haveHv -lt $wantHv) {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine -like '*server.ps1*' -and $_.CommandLine -like "*-Port*$port*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    for ($i = 0; $i -lt 30 -and (Test-Port $port 100); $i++) { Start-Sleep -Milliseconds 100 }
    $running = $false
  }
}
if (-not $running) {
  Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$script`"",'-WebRoot',"`"$base\web`"",'-DataDir',"`"$data`"",'-Port',"$port")
  for ($i = 0; $i -lt 150 -and -not (Test-Port $port 100); $i++) { Start-Sleep -Milliseconds 50 }
}

$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $edge) { Start-Process "http://127.0.0.1:$port/"; exit }
Start-Process $edge -ArgumentList @("--app=http://127.0.0.1:$port/", "--user-data-dir=`"$prof`"", '--window-size=1440,900', '--no-first-run', '--no-default-browser-check', '--autoplay-policy=no-user-gesture-required')
