# M-01 Companion launcher (Windows)
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 47811
$data = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Companion'
$prof = Join-Path $env:LOCALAPPDATA 'M-01 Companion\browser'
New-Item -ItemType Directory -Path $data, $prof -Force | Out-Null

# already open? bring it to the front instead of opening another window
$open = Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like "*$prof*" }
if ($open) { $wsh = New-Object -ComObject WScript.Shell; $null = $wsh.AppActivate('M-01 Companion'); exit }

function Test-Helper { try { (Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$port/ping" -Headers @{ 'X-M01' = '1' } -TimeoutSec 1).StatusCode -eq 200 } catch { $false } }
# a helper left running from an older install is replaced, so new features (like music) work right away
$wantHv = 0; try { $m = [regex]::Match([IO.File]::ReadAllText("$base\server.ps1"), '\$HV = (\d+)'); if ($m.Success) { $wantHv = [int]$m.Groups[1].Value } } catch { }
$haveHv = 0; try { $haveHv = [int]((Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$port/ping" -Headers @{ 'X-M01' = '1' } -TimeoutSec 1).Content | ConvertFrom-Json).hv } catch { $haveHv = 0 }
if ((Test-Helper) -and $wantHv -gt 0 -and $haveHv -lt $wantHv) {
  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and $_.CommandLine -like '*server.ps1*' -and $_.CommandLine -like "*-Port*$port*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  for ($i = 0; $i -lt 20 -and (Test-Helper); $i++) { Start-Sleep -Milliseconds 200 }
}
if (-not (Test-Helper)) {
  Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$base\server.ps1`"",'-WebRoot',"`"$base\web`"",'-DataDir',"`"$data`"",'-Port',"$port")
  for ($i = 0; $i -lt 40 -and -not (Test-Helper); $i++) { Start-Sleep -Milliseconds 300 }
}

function Test-Ollama { try { Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 | Out-Null; $true } catch { $false } }
if (-not (Test-Ollama)) {
  # local AI is optional: only wait for Ollama when it is installed
  $exe = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama app.exe'
  if (Test-Path $exe) {
    Start-Process $exe
    for ($i = 0; $i -lt 30 -and -not (Test-Ollama); $i++) { Start-Sleep -Seconds 1 }
  }
}

$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $edge) { Start-Process "http://127.0.0.1:$port/"; exit }
Start-Process $edge -ArgumentList @("--app=http://127.0.0.1:$port/", "--user-data-dir=`"$prof`"", '--window-size=1440,900', '--no-first-run', '--autoplay-policy=no-user-gesture-required')
