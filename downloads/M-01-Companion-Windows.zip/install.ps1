﻿# M-01 Companion 安裝程式（Windows）
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
Get-ChildItem -LiteralPath $src -Recurse | Unblock-File -ErrorAction SilentlyContinue
Write-Host "== 安裝 M-01 Companion / Installing M-01 Companion ==" -ForegroundColor Yellow

# 關掉正在執行的舊版（視窗和背景小幫手），新版才會完整生效
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and ($_.CommandLine -like '*M-01 Companion\app\server.ps1*' -or $_.CommandLine -like '*M-01 Companion\browser*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$dest = Join-Path $env:LOCALAPPDATA 'M-01 Companion\app'
New-Item -ItemType Directory -Path (Join-Path $dest 'web') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $src 'index.html') -Destination (Join-Path $dest 'web\index.html') -Force
foreach ($f in 'server.ps1','launch.ps1','icon.ico','gclient.txt') { Copy-Item -LiteralPath (Join-Path $src $f) -Destination (Join-Path $dest $f) -Force }
New-Item -ItemType Directory -Path (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Companion') -Force | Out-Null

# 讓 Ollama（之後在 App 裡安裝的話）允許這個 App 連線；AI 會在 App 裡登入後再設定
[Environment]::SetEnvironmentVariable('OLLAMA_ORIGINS', '*', 'User')

# 建立桌面與開始功能表捷徑
$wsh = New-Object -ComObject WScript.Shell
$targets = @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'M-01 Companion.lnk'), (Join-Path ([Environment]::GetFolderPath('Programs')) 'M-01 Companion.lnk'))
foreach ($t in $targets) {
  $s = $wsh.CreateShortcut($t)
  $s.TargetPath = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
  $s.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$dest\launch.ps1`""
  $s.IconLocation = "$dest\icon.ico"
  $s.WorkingDirectory = $dest
  $s.WindowStyle = 7
  $s.Description = 'M-01 Companion'
  $s.Save()
}
# refresh Windows' icon cache so the new sharper icon shows right away
try { Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\ie4uinit.exe') -ArgumentList '-show' -WindowStyle Hidden -ErrorAction SilentlyContinue } catch { }
Write-Host ""
$ver = [regex]::Match([IO.File]::ReadAllText((Join-Path $dest 'web\index.html'), [Text.Encoding]::UTF8), 'APP_VER="([0-9.]+)"').Groups[1].Value
Write-Host "已安裝版本 / Installed version: $ver（打開 App 後點右上角 ⓘ 應該也是這個版本 / the ⓘ button in the app should show the same）" -ForegroundColor Green
Write-Host "✅ 安裝完成！桌面和開始功能表都有「M-01 Companion」，以後點它就能打開。" -ForegroundColor Green
Write-Host "✅ Done! Open M-01 Companion from the desktop or the Start menu." -ForegroundColor Green
Write-Host "打開 App 後：先用 Google 登入，再選要用哪個 AI（Gemini、本地 AI 或 Claude），照畫面做就好。" -ForegroundColor Cyan
Write-Host "In the app: sign in with Google, then choose an AI (Gemini, local AI or Claude) and follow the steps on screen." -ForegroundColor Cyan
Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$dest\launch.ps1`"")
