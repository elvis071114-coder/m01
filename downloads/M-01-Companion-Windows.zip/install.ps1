﻿# M-01 Companion 安裝程式（Windows）
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
Get-ChildItem -LiteralPath $src -Recurse | Unblock-File -ErrorAction SilentlyContinue
Write-Host "== 安裝 M-01 Companion ==" -ForegroundColor Yellow

# 本地 AI（Ollama）是選用的：沒裝也可以，之後用 Gemini 或 Claude
$ollama = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
$hasOllama = Test-Path $ollama
if (-not $hasOllama) {
  $cmd = Get-Command ollama -ErrorAction SilentlyContinue
  if ($cmd) { $ollama = $cmd.Source; $hasOllama = $true }
}

# 關掉正在執行的舊版（視窗和背景小幫手），新版才會完整生效
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and ($_.CommandLine -like '*M-01 Companion\app\server.ps1*' -or $_.CommandLine -like '*M-01 Companion\browser*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$dest = Join-Path $env:LOCALAPPDATA 'M-01 Companion\app'
New-Item -ItemType Directory -Path (Join-Path $dest 'web') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $src 'index.html') -Destination (Join-Path $dest 'web\index.html') -Force
foreach ($f in 'server.ps1','launch.ps1','icon.ico') { Copy-Item -LiteralPath (Join-Path $src $f) -Destination (Join-Path $dest $f) -Force }
New-Item -ItemType Directory -Path (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Companion') -Force | Out-Null

# 讓 Ollama（如果有裝）允許這個 App 連線
[Environment]::SetEnvironmentVariable('OLLAMA_ORIGINS', '*', 'User')
$haveModel = $false
if ($hasOllama) {
  Get-Process -Name 'ollama app','ollama' -ErrorAction SilentlyContinue | Stop-Process -Force
  Start-Sleep -Seconds 2
  $app = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama app.exe'
  if (Test-Path $app) { Start-Process $app } else { Start-Process $ollama -ArgumentList 'serve' -WindowStyle Hidden }
  Start-Sleep -Seconds 4
  $list = & $ollama list 2>$null | Out-String
  if ($list -match 'qwen3\.5:(4b|9b|27b)|qwen2\.5:(7b|3b)') { $haveModel = $true; Write-Host "已經有本地 AI 模型，跳過下載。" -ForegroundColor Green }
}

# 選擇要不要本地 AI（可以之後在 App 的「設定 → AI」再下載或刪掉）
if (-not $haveModel) {
  Write-Host ""
  $ramGB = 0; try { $ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB) } catch { }
  $rec = '1'; if ($ramGB -gt 0 -and $ramGB -lt 14) { $rec = '2' }
  Write-Host "要不要安裝本地 AI？（免費、不用網路，但要佔硬碟空間）" -ForegroundColor Yellow
  Write-Host "  1) 標準版 qwen3.5:9b — 約 6.6GB，適合 16GB 以上的電腦"
  Write-Host "  2) 輕量版 qwen3.5:4b — 約 3.3GB，適合 8GB 的電腦，但比較容易答錯"
  Write-Host "  3) 不要本地 AI — 只用 Gemini（免費金鑰）或 Claude，最省空間"
  if ($ramGB -gt 0) { Write-Host "你的電腦有 $ramGB GB 記憶體，建議選 $rec。（更大的強力版可以之後在 App 的「設定 → AI」下載）" -ForegroundColor Cyan }
  $ch = Read-Host "輸入 1、2 或 3 再按 Enter（直接按 Enter 就是 $rec）"
  if (-not $ch) { $ch = $rec }
  if ($ch -eq '3') {
    Write-Host "好，不安裝本地 AI。打開 App 後貼上免費的 Gemini 金鑰就能開始；之後想要本地 AI，可以在「設定 → AI」下載。" -ForegroundColor Green
  } else {
    $model = if ($ch -eq '2') { 'qwen3.5:4b' } else { 'qwen3.5:9b' }
    if ($hasOllama) {
      Write-Host "正在下載 $model（第一次需要幾分鐘）..." -ForegroundColor Yellow
      & $ollama pull $model
      if ($LASTEXITCODE -ne 0) { Write-Host "模型下載沒有完成。可能是 Ollama 版本太舊：到 https://ollama.com/download 更新後，在 App 的「設定 → AI」再下載就好。" -ForegroundColor Yellow }
    } else {
      Write-Host "本地 AI 需要先安裝 Ollama，正在打開下載頁面。" -ForegroundColor Yellow
      Write-Host "裝好並打開 Ollama 後，到 App 的「設定 → AI」按「下載」就好，不用重新安裝 App。" -ForegroundColor Yellow
      Start-Process 'https://ollama.com/download/windows'
    }
  }
}

# 建立桌面與開始功能表捷徑
$wsh = New-Object -ComObject WScript.Shell
$targets = @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'M-01 Companion.lnk'), (Join-Path ([Environment]::GetFolderPath('Programs')) 'M-01 Companion.lnk'))
foreach ($t in $targets) {
  $s = $wsh.CreateShortcut($t)
  $s.TargetPath = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
  $s.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$dest\launch.ps1`""
  $s.IconLocation = "$dest\icon.ico"
  $s.WorkingDirectory = $dest
  $s.WindowStyle = 7
  $s.Description = 'M-01 Companion'
  $s.Save()
}
Write-Host ""
$ver = [regex]::Match([IO.File]::ReadAllText((Join-Path $dest 'web\index.html'), [Text.Encoding]::UTF8), 'APP_VER="([0-9.]+)"').Groups[1].Value
Write-Host "已安裝版本：$ver（打開 App 後點右上角 ⓘ 應該也是這個版本）" -ForegroundColor Green
Write-Host "✅ 安裝完成！桌面和開始功能表都有「M-01 Companion」，以後點它就能打開。" -ForegroundColor Green
Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$dest\launch.ps1`"")
