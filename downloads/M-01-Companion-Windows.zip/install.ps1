﻿# M-01 Companion 安裝程式（Windows）
$ErrorActionPreference = 'Stop'
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
Get-ChildItem -LiteralPath $src -Recurse | Unblock-File -ErrorAction SilentlyContinue
Write-Host "== 安裝 M-01 Companion ==" -ForegroundColor Yellow

$ollama = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
if (-not (Test-Path $ollama)) {
  $cmd = Get-Command ollama -ErrorAction SilentlyContinue
  if ($cmd) { $ollama = $cmd.Source } else {
    Write-Host "還沒安裝 Ollama，正在打開下載頁面。裝好 Ollama 後，再執行一次「安裝.bat」。" -ForegroundColor Red
    Start-Process 'https://ollama.com/download/windows'; exit 1
  }
}

# 關掉正在執行的舊版（視窗和背景小幫手），新版才會完整生效
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and ($_.CommandLine -like '*M-01 Companion\app\server.ps1*' -or $_.CommandLine -like '*M-01 Companion\browser*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
$dest = Join-Path $env:LOCALAPPDATA 'M-01 Companion\app'
New-Item -ItemType Directory -Path (Join-Path $dest 'web') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $src 'index.html') -Destination (Join-Path $dest 'web\index.html') -Force
foreach ($f in 'server.ps1','launch.ps1','icon.ico') { Copy-Item -LiteralPath (Join-Path $src $f) -Destination (Join-Path $dest $f) -Force }
New-Item -ItemType Directory -Path (Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Companion') -Force | Out-Null

# 讓 Ollama 允許這個 App 連線，並重新啟動 Ollama
[Environment]::SetEnvironmentVariable('OLLAMA_ORIGINS', '*', 'User')
Get-Process -Name 'ollama app','ollama' -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
$app = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama app.exe'
if (Test-Path $app) { Start-Process $app } else { Start-Process $ollama -ArgumentList 'serve' -WindowStyle Hidden }
Start-Sleep -Seconds 4

# 下載聊天模型（可以選大小）
$list = & $ollama list 2>$null | Out-String
if ($list -match 'qwen2\.5:(7b|3b)') { Write-Host "已經有聊天模型，跳過下載。" -ForegroundColor Green }
else {
  Write-Host ""
  Write-Host "要下載哪一個聊天模型？" -ForegroundColor Yellow
  Write-Host "  1) 標準版 qwen2.5:7b — 約 4.7GB，比較聰明、比較會照個性說話（建議）"
  Write-Host "  2) 輕量版 qwen2.5:3b — 約 1.9GB，下載快、比較省空間，但比較容易答錯"
  $ch = Read-Host "輸入 1 或 2 再按 Enter（直接按 Enter 就是 1）"
  $model = if ($ch -eq '2') { 'qwen2.5:3b' } else { 'qwen2.5:7b' }
  Write-Host "正在下載 $model（第一次需要幾分鐘）..." -ForegroundColor Yellow
  & $ollama pull $model
}

# 建立桌面與開始功能表捷徑
$wsh = New-Object -ComObject WScript.Shell
$targets = @((Join-Path ([Environment]::GetFolderPath('Desktop')) 'M-01 Companion.lnk'), (Join-Path ([Environment]::GetFolderPath('Programs')) 'M-01 Companion.lnk'))
foreach ($t in $targets) {
  $s = $wsh.CreateShortcut($t)
  $s.TargetPath = "$env:WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe"
  $s.Arguments = "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$dest\launch.ps1`""
  $s.IconLocation = "$dest\icon.ico"
  $s.WorkingDirectory = $dest
  $s.WindowStyle = 7
  $s.Description = 'M-01 Companion'
  $s.Save()
}
Write-Host ""
$ver = [regex]::Match([IO.File]::ReadAllText((Join-Path $dest 'web\index.html'), [Text.Encoding]::UTF8), 'APP_VER="([0-9.]+)"').Groups[1].Value
Write-Host "已安裝版本：$ver（打開 App 後點右上角 ⓘ 應該也是這個版本）" -ForegroundColor Green
Write-Host "✅ 安裝完成！桌面和開始功能表都有「M-01 Companion」，以後點它就能打開。" -ForegroundColor Green
Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$dest\launch.ps1`"")
