# M-01 Companion local helper for Windows: serves the app and reads/writes the memory folder.
# Listens on 127.0.0.1 only. Uses only what ships with Windows PowerShell 5.1.
param([string]$WebRoot, [string]$DataDir, [int]$Port = 47811)
$ErrorActionPreference = 'Continue'
# the user can move the memory folder from inside the app; remember their choice
$CfgFile = Join-Path $env:LOCALAPPDATA 'M-01 Companion\datadir.txt'
if (Test-Path -LiteralPath $CfgFile) { $saved = ([IO.File]::ReadAllText($CfgFile, [Text.Encoding]::UTF8)).Trim(); if ($saved -and (Test-Path -LiteralPath $saved)) { $DataDir = $saved } }
$KeyFile = Join-Path $env:LOCALAPPDATA 'M-01 Companion\claude_key.txt'
$GemKeyFile = Join-Path $env:LOCALAPPDATA 'M-01 Companion\gemini_key.txt'
$FishKeyFile = Join-Path $env:LOCALAPPDATA 'M-01 Companion\fish_key.txt'
$GoogFile = Join-Path $env:LOCALAPPDATA 'M-01 Companion\google_token.txt'
$GCodeFile = Join-Path $env:LOCALAPPDATA 'M-01 Companion\google_code.txt'
$GTokUrl = 'https://oauth2.googleapis.com/token'; if ($env:M01_GTOKEN_URL) { $GTokUrl = $env:M01_GTOKEN_URL }
$GSecret = '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'   # desktop-app sign-in client: Google treats this one as public
$WebOvr = Join-Path $env:LOCALAPPDATA 'M-01 Companion\web'
$HV = 2   # helper version: the page asks for a reinstall when a newer helper is needed
function Page-Ver([string]$t) { $m = [regex]::Match([string]$t, 'const APP_VER="(\d+)\.(\d+)\.(\d+)"'); if ($m.Success) { return ([int]$m.Groups[1].Value)*1000000 + ([int]$m.Groups[2].Value)*1000 + [int]$m.Groups[3].Value }; return 0 }
$DataMark = [regex]::Unescape('_\u8cc7\u6599\uff08\u8acb\u52ff\u4fee\u6539\uff09')
if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory -Path $DataDir -Force | Out-Null }
$DataDir = (Resolve-Path $DataDir).Path
$utf8 = New-Object System.Text.UTF8Encoding($false)
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Parse('127.0.0.1'), $Port)
try { $listener.Start() } catch { exit 1 }

$Types = @{ html='text/html; charset=utf-8'; js='text/javascript'; css='text/css'; json='application/json'; png='image/png'; ico='image/x-icon'; md='text/markdown; charset=utf-8' }

function Send-Reply($stream, [int]$code, [string]$type, [byte[]]$body) {
  if ($null -eq $body) { $body = [byte[]]@() }
  $msg = @{200='OK';204='No Content';400='Bad Request';403='Forbidden';404='Not Found';405='Method Not Allowed'}[$code]
  $head = "HTTP/1.1 $code $msg`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
  $hb = [System.Text.Encoding]::ASCII.GetBytes($head)
  $stream.Write($hb, 0, $hb.Length)
  if ($body.Length -gt 0) { $stream.Write($body, 0, $body.Length) }
}
function Send-Text($stream, [int]$code, [string]$type, [string]$text) { Send-Reply $stream $code $type ($utf8.GetBytes($text)) }
function Json-Str([string]$s) { return ($s | ConvertTo-Json -Compress) }
function Safe-Rel([string]$raw) {
  $p = [System.Uri]::UnescapeDataString($raw).TrimStart('/')
  foreach ($seg in $p.Split('/')) { if ($seg -eq '..' -or $seg -eq '.') { return $null } }
  if ($p -match '[\x00]') { return $null }
  return $p
}
function Html-Text([string]$h) {
  $h = [regex]::Replace($h, '(?is)<(script|style|noscript|svg|head)\b.*?</\1>', ' ')
  $h = [regex]::Replace($h, '(?i)<br\s*/?>|</p>|</div>|</li>|</h\d>', "`n")
  $h = [regex]::Replace($h, '<[^>]+>', ' ')
  $h = [System.Net.WebUtility]::HtmlDecode($h)
  $h = [regex]::Replace($h, '[ \t\r\f]+', ' ')
  $h = [regex]::Replace($h, '\n\s*\n+', "`n")
  return $h.Trim()
}
function Fetch-Url([string]$url, [int]$secs) {
  if ($url -notmatch '^https?://') { return $null }
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec $secs -UserAgent 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'
    return [string]$r.Content
  } catch { return $null }
}
function Parse-Query([string]$qs) {
  $q = @{}
  foreach ($pair in $qs.Split('&')) { if ($pair) { $kv = $pair.Split('=', 2); $q[$kv[0]] = if ($kv.Length -gt 1) { [System.Uri]::UnescapeDataString($kv[1].Replace('+', ' ')) } else { '' } } }
  return $q
}

while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
    $client.ReceiveTimeout = 15000
    $stream = $client.GetStream()
    # read headers
    $buf = New-Object byte[] 65536; $ms = New-Object System.IO.MemoryStream; $headerEnd = -1
    while ($headerEnd -lt 0) {
      $n = $stream.Read($buf, 0, $buf.Length); if ($n -le 0) { break }
      $ms.Write($buf, 0, $n)
      $all = $ms.ToArray()
      for ($i = 3; $i -lt $all.Length; $i++) { if ($all[$i-3] -eq 13 -and $all[$i-2] -eq 10 -and $all[$i-1] -eq 13 -and $all[$i] -eq 10) { $headerEnd = $i + 1; break } }
    }
    if ($headerEnd -lt 0) { $client.Close(); continue }
    $all = $ms.ToArray()
    $headText = [System.Text.Encoding]::ASCII.GetString($all, 0, $headerEnd)
    $lines = $headText -split "`r`n"
    $parts = $lines[0].Split(' ')
    $method = $parts[0]; $target = $parts[1]
    $h = @{}
    foreach ($l in $lines[1..($lines.Length-1)]) { $ix = $l.IndexOf(':'); if ($ix -gt 0) { $h[$l.Substring(0,$ix).Trim().ToLower()] = $l.Substring($ix+1).Trim() } }
    # body
    $len = 0; if ($h.ContainsKey('content-length')) { $len = [int]$h['content-length'] }
    $body = New-Object byte[] $len
    $have = $all.Length - $headerEnd
    if ($have -gt 0) { [Array]::Copy($all, $headerEnd, $body, 0, [Math]::Min($have, $len)) }
    while ($have -lt $len) { $n = $stream.Read($body, $have, $len - $have); if ($n -le 0) { break }; $have += $n }

    $qs = ''; $qi = $target.IndexOf('?'); if ($qi -ge 0) { $qs = $target.Substring($qi+1); $target = $target.Substring(0, $qi) }
    $isApi = $target -match '^/(fs|ls|ping|search|fetch|open|battery|reveal|setdata|getjson|secret|uninstall|gemini|fishtts|gtoken|selfupdate)(/|$)'
    if ($isApi -and $h['x-m01'] -ne '1') { Send-Text $stream 403 'text/plain' 'forbidden'; $client.Close(); continue }

    if ($target -eq '/battery') {
      $b = $null; try { $b = Get-CimInstance -ClassName Win32_Battery -ErrorAction Stop | Select-Object -First 1 } catch {}
      if ($b -and $b.EstimatedChargeRemaining -ne $null) {
        $ch = 'false'; if (@(2,6,7,8,9) -contains [int]$b.BatteryStatus) { $ch = 'true' }
        Send-Text $stream 200 'application/json' ('{"ok":true,"level":' + [int]$b.EstimatedChargeRemaining + ',"charging":' + $ch + '}')
      } else { Send-Text $stream 200 'application/json' '{"ok":false}' }
    }
    elseif ($target -eq '/getjson') {
      $q = Parse-Query $qs; $u = [string]$q['url']
      if (($u -match '^https://(geocoding-api|api)\.open-meteo\.com/') -or ($u -match '^https://(raw\.githubusercontent\.com|gist\.githubusercontent\.com|[A-Za-z0-9-]+\.github\.io)/\S*\.json(\?\S*)?$')) {
        $bytes = $null
        try {
          [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
          $resp = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 12
          $bytes = $resp.RawContentStream.ToArray()
        } catch { $bytes = $null }
        if ($bytes -and $bytes.Length -gt 0) { Send-Reply $stream 200 'application/json; charset=utf-8' $bytes } else { Send-Text $stream 200 'application/json' '{"error":true,"reason":"unreachable"}' }
      } else { Send-Text $stream 403 'text/plain' 'forbidden' }
    }
    elseif ($target -eq '/secret') {
      $qs0 = Parse-Query $qs; $KF = $KeyFile; if ($qs0['p'] -eq 'gemini') { $KF = $GemKeyFile } elseif ($qs0['p'] -eq 'fish') { $KF = $FishKeyFile } elseif ($qs0['p'] -eq 'google') { $KF = $GoogFile } elseif ($qs0['p'] -eq 'gcode') { $KF = $GCodeFile }
      if ($method -eq 'PUT') {
        $k = ''; if ($body.Length -gt 0) { $k = $utf8.GetString($body).Trim() }
        if ($k) { New-Item -ItemType Directory -Path (Split-Path -Parent $KF) -Force | Out-Null; [IO.File]::WriteAllText($KF, $k, $utf8) }
        elseif (Test-Path -LiteralPath $KF) { Remove-Item -LiteralPath $KF -Force }
        Send-Text $stream 200 'application/json' '{"ok":true}'
      }
      elseif ($method -eq 'DELETE') { if (Test-Path -LiteralPath $KF) { Remove-Item -LiteralPath $KF -Force }; Send-Text $stream 200 'application/json' '{"ok":true}' }
      else {
        $k = ''; if (Test-Path -LiteralPath $KF) { $k = ([IO.File]::ReadAllText($KF, $utf8)).Trim() }
        $q = Parse-Query $qs
        if ($q['reveal'] -eq '1' -and $qs0['p'] -ne 'google') { Send-Text $stream 200 'application/json' ('{"ok":true,"key":' + (Json-Str $k) + '}') }
        else { $l4 = ''; if ($k.Length -gt 4) { $l4 = $k.Substring($k.Length - 4) }; $has = 'false'; if ($k) { $has = 'true' }
          Send-Text $stream 200 'application/json' ('{"ok":true,"has":' + $has + ',"last4":' + (Json-Str $l4) + '}') }
      }
    }
    elseif ($target -eq '/oauth') {
      # Google sign-in comes back here in the browser: hand the one-time code to the app, then say done
      $q = Parse-Query $qs; $st = [string]$q['state']; $cd = [string]$q['code']; $er = [string]$q['error']
      $okk = ($st -match '^m01g[A-Za-z0-9]+$') -and ($cd -or $er)
      if ($okk) { $v = $cd; if (-not $cd) { $v = '!' + $er }; New-Item -ItemType Directory -Path (Split-Path -Parent $GCodeFile) -Force | Out-Null; [IO.File]::WriteAllText($GCodeFile, ($st + ' ' + $v), $utf8) }
      $msg = 'BAD'; if ($okk -and $cd) { $msg = 'OK' } elseif ($okk) { $msg = 'CANCEL' }
      $page = '<!DOCTYPE html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>M-01 Companion</title><body style="margin:0;display:grid;place-items:center;min-height:100vh;background:#0b0b0e;color:#eee;font:17px/1.8 system-ui,sans-serif;text-align:center"><div><div style="color:#ff7a3d;letter-spacing:.2em;font-size:13px">M-01 COMPANION</div><p>' + $msg + '</p></div><script>setTimeout(function(){try{window.close()}catch(e){}},1500)</script></body>'
      $page = $page.Replace('<p>OK</p>', '<p>&#30331;&#20837;&#25104;&#21151;&#65281;&#21487;&#20197;&#38364;&#25481;&#36889;&#20491;&#20998;&#38913;&#65292;&#22238;&#21040; M-01 &#20102;&#12290;<br>Signed in! You can close this tab and go back to M-01.</p>').Replace('<p>CANCEL</p>', '<p>&#20320;&#21462;&#28040;&#20102;&#30331;&#20837;&#12290;&#21487;&#20197;&#38364;&#25481;&#36889;&#20491;&#20998;&#38913;&#65292;&#22238;&#21040; M-01&#12290;<br>Sign-in was cancelled. You can close this tab and go back to M-01.</p>').Replace('<p>BAD</p>', '<p>&#30331;&#20837;&#27794;&#26377;&#23436;&#25104;&#65292;&#35531;&#22238;&#21040; M-01 &#20877;&#35430;&#19968;&#27425;&#12290;<br>Sign-in didn&#8217;t finish - go back to M-01 and try again.</p>')
      Send-Text $stream 200 'text/html; charset=utf-8' $page
    }
    elseif ($target -eq '/gtoken') {
      # Google sign-in tokens: the long-lived refresh token stays in a local file, the page only gets short access tokens
      $q = Parse-Query $qs; $form = ''; if ($body.Length -gt 0) { $form = $utf8.GetString($body) }
      if ($form -notmatch '(^|&)client_secret=') { $form = $form + '&client_secret=' + $GSecret }
      $skip = $false
      if ($q['op'] -eq 'refresh') {
        $rt = ''; if (Test-Path -LiteralPath $GoogFile) { $rt = ([IO.File]::ReadAllText($GoogFile, $utf8)).Trim() }
        if (-not $rt) { Send-Text $stream 200 'application/json' '{"status":401,"body":{"error":"not_signed_in"}}'; $skip = $true }
        else { $form = $form + '&refresh_token=' + [Uri]::EscapeDataString($rt) }
      }
      if (-not $skip) {
        $code = 0; $txt = ''
        try {
          [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
          $resp = Invoke-WebRequest -Uri $GTokUrl -Method Post -Body $form -ContentType 'application/x-www-form-urlencoded' -UseBasicParsing -TimeoutSec 30
          $code = [int]$resp.StatusCode; $txt = $utf8.GetString($resp.RawContentStream.ToArray())
        } catch {
          $er = $_.Exception.Response
          if ($er) { $code = [int]$er.StatusCode; try { $sr = New-Object IO.StreamReader($er.GetResponseStream(), $utf8); $txt = $sr.ReadToEnd() } catch { $txt = '' } }
        }
        $m = [regex]::Match($txt, '"refresh_token"\s*:\s*"([^"]+)"')
        if ($m.Success) {
          New-Item -ItemType Directory -Path (Split-Path -Parent $GoogFile) -Force | Out-Null; [IO.File]::WriteAllText($GoogFile, $m.Groups[1].Value, $utf8)
          $t2 = [regex]::Replace($txt, ',\s*"refresh_token"\s*:\s*"[^"]*"', '')
          if ($t2 -eq $txt) { $t2 = [regex]::Replace($txt, '"refresh_token"\s*:\s*"[^"]*"\s*,?', '') }
          $txt = $t2
        }
        if ($txt -notmatch '^\s*[\[{]') { $txt = 'null' }
        Send-Text $stream 200 'application/json' ('{"status":' + $code + ',"body":' + $txt + '}')
      }
    }
    elseif ($target -eq '/gemini') {
      $q = Parse-Query $qs
      $model = ([string]$q['model']) -replace '[^A-Za-z0-9.\-]', ''
      if (-not $model) { $model = 'gemini-3.8-flash' }
      $gk = ''; if (Test-Path -LiteralPath $GemKeyFile) { $gk = ([IO.File]::ReadAllText($GemKeyFile, $utf8)).Trim() }
      if (-not $gk) { Send-Text $stream 200 'application/json' '{"status":401,"body":{"error":{"message":"no key"}}}' }
      else {
        $gbase = 'https://generativelanguage.googleapis.com'; if ($env:M01_GEMINI_URL) { $gbase = $env:M01_GEMINI_URL }
        $code = 0; $txt = ''
        try {
          [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
          $resp = Invoke-WebRequest -Uri ($gbase + '/v1beta/models/' + $model + ':generateContent') -Method Post -Body $body -ContentType 'application/json; charset=utf-8' -Headers @{ 'x-goog-api-key' = $gk } -UseBasicParsing -TimeoutSec 120
          $code = [int]$resp.StatusCode; $txt = $utf8.GetString($resp.RawContentStream.ToArray())
        } catch {
          $er = $_.Exception.Response
          if ($er) { $code = [int]$er.StatusCode; try { $sr = New-Object IO.StreamReader($er.GetResponseStream(), $utf8); $txt = $sr.ReadToEnd() } catch { $txt = '' } }
        }
        if ($txt -notmatch '^\s*[\[{]') { $txt = 'null' }
        Send-Text $stream 200 'application/json' ('{"status":' + $code + ',"body":' + $txt + '}')
      }
    }
    elseif ($target -eq '/fishtts') {
      $q = Parse-Query $qs
      $model = ([string]$q['model']) -replace '[^A-Za-z0-9.\-]', ''
      if (-not $model) { $model = 's2.1-pro-free' }
      $fk = ''; if (Test-Path -LiteralPath $FishKeyFile) { $fk = ([IO.File]::ReadAllText($FishKeyFile, $utf8)).Trim() }
      if (-not $fk) { Send-Text $stream 200 'application/json' '{"status":401,"error":"no key"}' }
      else {
        $fbase = 'https://api.fish.audio'; if ($env:M01_FISH_URL) { $fbase = $env:M01_FISH_URL }
        $code = 0; $bytes = $null; $etxt = ''
        try {
          [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
          $resp = Invoke-WebRequest -Uri ($fbase + '/v1/tts') -Method Post -Body $body -ContentType 'application/json; charset=utf-8' -Headers @{ 'Authorization' = ('Bearer ' + $fk); 'model' = $model } -UseBasicParsing -TimeoutSec 90
          $code = [int]$resp.StatusCode; $bytes = $resp.RawContentStream.ToArray()
        } catch {
          $er = $_.Exception.Response
          if ($er) { $code = [int]$er.StatusCode; try { $sr = New-Object IO.StreamReader($er.GetResponseStream(), $utf8); $etxt = $sr.ReadToEnd() } catch { $etxt = '' } }
        }
        if ($code -eq 200 -and $bytes -and $bytes.Length -gt 0) { Send-Reply $stream 200 'audio/mpeg' $bytes }
        else { if ($etxt.Length -gt 400) { $etxt = $etxt.Substring(0, 400) }; $etxt = $etxt -replace '[^\x20-\x7e]', ''
          Send-Text $stream 200 'application/json' ('{"status":' + $code + ',"error":' + (Json-Str $etxt) + '}') }
      }
    }
    elseif ($target -eq '/uninstall') {
      $q = Parse-Query $qs
      $moved = 'false'
      $safe = ((Split-Path -Leaf $DataDir) -eq 'Companion') -or (Test-Path -LiteralPath (Join-Path $DataDir $DataMark))
      if ($q['data'] -eq '1' -and $safe -and ($DataDir -ne $env:USERPROFILE)) {
        try {
          Add-Type -AssemblyName Microsoft.VisualBasic
          [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory($DataDir, [Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs, [Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin)
          $moved = 'true'
        } catch { $moved = 'false' }
      }
      Send-Text $stream 200 'application/json' ('{"ok":true,"dataMoved":' + $moved + ',"data":' + (Json-Str $DataDir) + '}')
      $root = Split-Path -Parent (Split-Path -Parent $WebRoot)
      if ((Split-Path -Leaf $root) -eq 'M-01 Companion') {
        $r = $root -replace "'", "''"
        $cmd = "Start-Sleep -Seconds 2; " +
          "Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { `$_.CommandLine -and `$_.CommandLine -like '*M-01 Companion\browser*' } | ForEach-Object { Stop-Process -Id `$_.ProcessId -Force -ErrorAction SilentlyContinue }; " +
          "Start-Sleep -Seconds 1; Remove-Item -LiteralPath '$r' -Recurse -Force -ErrorAction SilentlyContinue; " +
          "Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Desktop')) 'M-01 Companion.lnk') -Force -ErrorAction SilentlyContinue; " +
          "Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Programs')) 'M-01 Companion.lnk') -Force -ErrorAction SilentlyContinue; " +
          "[Environment]::SetEnvironmentVariable('OLLAMA_ORIGINS', `$null, 'User')"
        $enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cmd))
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', $enc)
      }
      try { $client.Close() } catch {}
      $listener.Stop()
      exit
    }
    elseif ($target -eq '/reveal') {
      Start-Process explorer.exe -ArgumentList ('"' + $DataDir + '"')
      Send-Text $stream 200 'application/json' ('{"ok":true,"data":' + (Json-Str $DataDir) + '}')
    }
    elseif ($target -eq '/setdata') {
      $p = ''
      try {
        Add-Type -AssemblyName System.Windows.Forms
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Choose where to keep the M-01 memory folder (a Companion folder will be created inside)'
        $dlg.SelectedPath = [Environment]::GetFolderPath('MyDocuments')
        $owner = New-Object System.Windows.Forms.Form
        $owner.TopMost = $true; $owner.ShowInTaskbar = $false
        if ($dlg.ShowDialog($owner) -eq [System.Windows.Forms.DialogResult]::OK) { $p = $dlg.SelectedPath }
        $owner.Dispose()
      } catch { $p = '' }
      if (-not $p) { Send-Text $stream 200 'application/json' '{"ok":false,"cancel":true}' }
      else {
        $p = $p.TrimEnd('\')
        $newDir = $p
        if ((Split-Path -Leaf $p) -ne 'Companion' -and -not (Test-Path -LiteralPath (Join-Path $p $DataMark))) { $newDir = Join-Path $p 'Companion' }
        try {
          New-Item -ItemType Directory -Path $newDir -Force | Out-Null
          $abs = (Resolve-Path -LiteralPath $newDir).Path
          if ($abs -ne $DataDir) {
            if (-not (Test-Path -LiteralPath (Join-Path $abs $DataMark))) { Copy-Item -Path (Join-Path $DataDir '*') -Destination $abs -Recurse -Force }
            New-Item -ItemType Directory -Path (Split-Path -Parent $CfgFile) -Force | Out-Null
            [IO.File]::WriteAllText($CfgFile, $abs, $utf8)
            $DataDir = $abs
          }
          Send-Text $stream 200 'application/json' ('{"ok":true,"data":' + (Json-Str $DataDir) + '}')
        } catch { Send-Text $stream 200 'application/json' '{"ok":false,"error":"cannot write"}' }
      }
    }
    elseif ($target -eq '/ping') {
      Send-Text $stream 200 'application/json' ('{"ok":true,"hv":' + $HV + ',"data":' + (Json-Str $DataDir) + '}')
    }
    elseif ($target -eq '/selfupdate') {
      # one-click update: download the new app page from GitHub into a local folder; it is served instead of the bundled one when newer
      $q = Parse-Query $qs; $u = [string]$q['url']; $ovf = Join-Path $WebOvr 'index.html'
      if ($method -eq 'DELETE') { if (Test-Path -LiteralPath $ovf) { Remove-Item -LiteralPath $ovf -Force }; Send-Text $stream 200 'application/json' '{"ok":true}' }
      elseif (($u -notmatch '^https://[A-Za-z0-9-]+\.github\.io/[^\s?#]*\.html$') -and -not ($env:M01_UPD_ALLOW -and $u.StartsWith($env:M01_UPD_ALLOW))) { Send-Text $stream 403 'text/plain' 'forbidden' }
      else {
        $bytes = $null
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $resp = Invoke-WebRequest -Uri $u -UseBasicParsing -TimeoutSec 90; $bytes = $resp.RawContentStream.ToArray() } catch { $bytes = $null }
        $txt = ''; if ($bytes) { $txt = $utf8.GetString($bytes) }
        $v = Page-Ver $txt
        if ($v -gt 0 -and $bytes.Length -gt 100000 -and $txt -match '</html>\s*$') {
          New-Item -ItemType Directory -Path $WebOvr -Force | Out-Null; $tmp = $ovf + '.tmp'
          [IO.File]::WriteAllBytes($tmp, $bytes); Move-Item -LiteralPath $tmp -Destination $ovf -Force
          Send-Text $stream 200 'application/json' ('{"ok":true,"v":' + $v + '}')
        } else { Send-Text $stream 200 'application/json' '{"ok":false,"error":"download"}' }
      }
    }
    elseif ($target -like '/fs/*') {
      $rel = Safe-Rel $target.Substring(4)
      if (-not $rel) { Send-Text $stream 400 'text/plain' 'bad path' }
      else {
        $f = Join-Path $DataDir ($rel -replace '/', '\')
        if ($method -eq 'GET') { if (Test-Path -LiteralPath $f -PathType Leaf) { Send-Reply $stream 200 'application/octet-stream' ([System.IO.File]::ReadAllBytes($f)) } else { Send-Text $stream 404 'text/plain' 'not found' } }
        elseif ($method -eq 'PUT') {
          $dir = Split-Path -Parent $f; if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
          $tmp = "$f.tmp"; [System.IO.File]::WriteAllBytes($tmp, $body); Move-Item -LiteralPath $tmp -Destination $f -Force
          Send-Reply $stream 204 'text/plain' $null
        }
        elseif ($method -eq 'DELETE') { if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force }; Send-Reply $stream 204 'text/plain' $null }
        else { Send-Text $stream 405 'text/plain' 'method' }
      }
    }
    elseif ($target -like '/ls*') {
      $rel = Safe-Rel ($target -replace '^/ls/?', '')
      if ($null -eq $rel) { Send-Text $stream 400 'text/plain' 'bad path' }
      else {
        $d = if ($rel -eq '') { $DataDir } else { Join-Path $DataDir ($rel -replace '/', '\') }
        $items = @()
        if (Test-Path -LiteralPath $d -PathType Container) {
          foreach ($e in (Get-ChildItem -LiteralPath $d -Force | Where-Object { -not $_.Name.StartsWith('.') } | Sort-Object Name)) {
            $items += ('{"name":' + (Json-Str $e.Name) + ',"dir":' + ($(if ($e.PSIsContainer) {'true'} else {'false'})) + '}')
          }
        }
        Send-Text $stream 200 'application/json' ('[' + ($items -join ',') + ']')
      }
    }
    elseif ($target -eq '/search') {
      $q = Parse-Query $qs
      $html = Fetch-Url ('https://html.duckduckgo.com/html/?kl=tw-tzh&q=' + [System.Uri]::EscapeDataString([string]$q['q'])) 12
      if (-not $html) { Send-Text $stream 200 'application/json' '{"ok":false,"error":"offline"}' }
      else {
        $out = @()
        $ms2 = [regex]::Matches($html, '(?s)<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>(.*?)</a>(.*?)(?=<a[^>]*class="[^"]*result__a|\z)')
        foreach ($m in $ms2) {
          $href = $m.Groups[1].Value
          $u = [regex]::Match($href, '[?&]uddg=([^&]+)'); if ($u.Success) { $href = [System.Uri]::UnescapeDataString($u.Groups[1].Value) }
          if ($href.StartsWith('//')) { $href = 'https:' + $href }
          if ($href -match 'duckduckgo\.com/y\.js') { continue }
          $sn = [regex]::Match($m.Groups[3].Value, '(?s)class="[^"]*result__snippet[^"]*"[^>]*>(.*?)</a>')
          $out += ('{"title":' + (Json-Str (Html-Text $m.Groups[2].Value)) + ',"url":' + (Json-Str $href) + ',"snippet":' + (Json-Str (Html-Text $sn.Groups[1].Value)) + '}')
          if ($out.Count -ge 6) { break }
        }
        Send-Text $stream 200 'application/json' ('{"ok":true,"results":[' + ($out -join ',') + ']}')
      }
    }
    elseif ($target -eq '/fetch') {
      $q = Parse-Query $qs
      $html = Fetch-Url ([string]$q['url']) 15
      if (-not $html) { Send-Text $stream 200 'application/json' '{"ok":false,"error":"unreachable"}' }
      else { $t = Html-Text $html; if ($t.Length -gt 9000) { $t = $t.Substring(0, 9000) }; Send-Text $stream 200 'application/json' ('{"ok":true,"text":' + (Json-Str $t) + '}') }
    }
    elseif ($target -eq '/open') {
      $q = Parse-Query $qs
      if ([string]$q['url'] -match '^https?://') { Start-Process ([string]$q['url']) }
      Send-Reply $stream 204 'text/plain' $null
    }
    else {
      $p = [System.Uri]::UnescapeDataString($target); if ($p -eq '/') { $p = '/index.html' }
      if ($p -match '\.\.') { Send-Text $stream 403 'text/plain' 'no' }
      else {
        $f = Join-Path $WebRoot ($p.TrimStart('/') -replace '/', '\')
        $ext = [System.IO.Path]::GetExtension($f).TrimStart('.').ToLower()
        $ovf = Join-Path $WebOvr 'index.html'
        if ($p -eq '/index.html' -and (Test-Path -LiteralPath $ovf -PathType Leaf) -and (Test-Path -LiteralPath $f -PathType Leaf) -and ((Page-Ver ([IO.File]::ReadAllText($ovf, $utf8))) -gt (Page-Ver ([IO.File]::ReadAllText($f, $utf8))))) { Send-Reply $stream 200 $Types['html'] ([System.IO.File]::ReadAllBytes($ovf)) }
        elseif (Test-Path -LiteralPath $f -PathType Leaf) { $t = $Types[$ext]; if (-not $t) { $t = 'application/octet-stream' }; Send-Reply $stream 200 $t ([System.IO.File]::ReadAllBytes($f)) }
        else { Send-Text $stream 404 'text/plain' 'not found' }
      }
    }
  } catch {
    try { Send-Text $stream 400 'text/plain' 'error' } catch {}
  } finally {
    try { $client.Close() } catch {}
  }
}
